"""Offline accounting and bounded pair scoring; no application imports or model calls."""

import argparse
import contextlib
import hashlib
import itertools
import json
import math
import sqlite3
from pathlib import Path

OUT = Path(__file__).resolve().parent
FIELDS = ("id", "source", "url", "title", "text", "published_at")
TOKENS = ("input_tokens", "output_tokens", "cached_input_tokens")
SHIP_NOS = "30ba9d82a4a224c0c84db4a0"
SHIP_BBC = "b5097a6c20686f5241b8f1aa"
CAT_BBC = "3ae710513a084e1b9f385449"
CAT_FOLLOWUP = "335bd8e8bb5da4c5bd57e22a"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def seconds(value):
    return type(value) in (int, float) and 0 <= value <= 1e9 and math.isfinite(value)


def group(label):
    if label.endswith("-baseline"):
        return "baseline"
    if label.endswith("-candidate"):
        return "candidate"
    if "-prior-" in label:
        return "shared_preparation"
    assert label in {"observed-bad", "inherited-bad", "positive-control"}, label
    return "controls"


def outcome(receipt):
    if receipt is None:
        return "unavailable"
    if receipt["accepted"]:
        return "succeeded"
    if receipt.get("rejection") or "story coherence review rejected" in receipt.get("error", ""):
        return "rejected"
    return "failed"


def assignment_rows(receipt):
    """Read only accepted rows through this receipt's run, never later continuation rows."""
    path = Path(receipt["state"]) / "journal.sqlite3"
    assert path.is_file(), path
    with contextlib.closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as db:
        assert db.execute("PRAGMA application_id").fetchone()[0] == 0x4E54524A
        row = db.execute("SELECT rowid FROM runs WHERE id=?", (receipt["run_id"],)).fetchone()
        assert row is not None, receipt["label"]
        rows = db.execute(
            "SELECT id, input_json, result_json FROM runs WHERE rowid<=? ORDER BY rowid",
            (row[0],),
        ).fetchall()
    assignments = {}
    for run_id, raw_input, raw_result in rows:
        payload, result = json.loads(raw_input), json.loads(raw_result)
        assert result["run_id"] == run_id
        sources = {article["id"]: article for article in payload["articles"]}
        for story in result["stories"]:
            for event in story["events"]:
                for observation in event["observations"]:
                    for source_id in observation["article_ids"]:
                        source = sources[source_id]
                        assignments[source_id] = {
                            "story_id": story["id"],
                            "event_id": event["id"],
                            "capture_id": source["capture_id"],
                            "run_id": run_id,
                            "identity_uncertain": event["identity_uncertain"],
                        }
    directory = Path(receipt["state"]) / "runs" / receipt["run_id"]
    assert read(directory / "input.json") == payload
    assert read(directory / "result.json") == result
    snapshot = read(receipt["input"])
    assert payload["day"] == snapshot["day"]
    assert sorted(
        ({key: article[key] for key in FIELDS} for article in payload["articles"]),
        key=lambda article: article["id"],
    ) == sorted(snapshot["articles"], key=lambda article: article["id"])
    return (
        assignments,
        payload,
        {"path": str(path), "sha256": sha(path), "through_run": receipt["run_id"]},
    )


def labeled_pairs(label, current_ids, kind):
    pairs = {}
    rules = label["story_relationships" if kind == "story" else "event_identity"]
    same = rules["same_story_groups" if kind == "story" else "same_event_groups"]
    for item in same:
        for pair in itertools.combinations(item["source_ids"], 2):
            pairs[tuple(sorted(pair))] = "same"
    if kind == "story":
        groups = {item["story_id"]: item["source_ids"] for item in same}
        different = (
            pair
            for left, right in rules["different_story_group_pairs"]
            for pair in itertools.product(groups[left], groups[right])
        )
    else:
        different = (item["source_ids"] for item in rules["different_event_pairs"])
    for pair in different:
        assert len(pair) == 2
        pair = tuple(sorted(pair))
        assert pairs.get(pair, "different") == "different", pair
        pairs[pair] = "different"
    scored, excluded = [], []
    for pair, expected in sorted(pairs.items()):
        item = {"source_ids": list(pair), "expected": expected}
        (scored if set(pair) & current_ids else excluded).append(item)
    return scored, excluded


def score_pairs(pairs, assignments, kind, unavailable=None):
    rows = []
    for pair in pairs:
        ids = pair["source_ids"]
        row = dict(pair)
        missing = [source_id for source_id in ids if source_id not in assignments]
        if unavailable or missing:
            row.update(
                status="unavailable",
                reason=unavailable or "missing accepted assignment",
                missing_ids=missing,
            )
        else:
            left, right = (assignments[source_id] for source_id in ids)
            same = left["story_id"] == right["story_id"]
            if kind == "event":
                same = same and left["event_id"] == right["event_id"]
            observed = "same" if same else "different"
            row.update(
                status="correct" if observed == pair["expected"] else "wrong",
                observed=observed,
                assignments={source_id: assignments[source_id] for source_id in ids},
            )
        rows.append(row)
    counts = {
        expected: {
            status: sum(row["expected"] == expected and row["status"] == status for row in rows)
            for status in ("correct", "wrong", "unavailable")
        }
        for expected in ("same", "different")
    }
    return {"counts": counts, "pairs": rows}


def fixed_context(case, source_versions, receipt, calls):
    label = receipt["label"]
    path = OUT / "author-inputs" / f"{label}.json"
    if not path.is_file():
        return None, {
            "available": False,
            "reason": "No frozen author input; exact source coverage not demonstrated.",
        }
    payload = read(path)
    current = {article["id"] for article in payload["articles"]}
    prior = {article["id"] for article in payload["prior_sources"]}
    details = {
        "path": str(path),
        "sha256": sha(path),
        "actual_current_ids": sorted(current),
        "actual_prior_ids": sorted(prior),
    }
    try:
        assert current == set(case["current_source_ids"]), (
            "Current source IDs differ from the frozen case."
        )
        assert prior == set(case["prior_source_ids"]), (
            "Prior source IDs differ from the frozen case."
        )
        assert len(payload["articles"]) == len(current), "Duplicate current IDs."
        assert len(payload["prior_sources"]) == len(prior), "Duplicate prior IDs."
        for article in payload["articles"] + payload["prior_sources"]:
            assert {field: article[field] for field in FIELDS} == source_versions[article["id"]][
                "article"
            ], "Source fields differ."
        author_calls = [
            call for call in calls if call["label"] == label and call["task"] == "trajectory"
        ]
        assert len(author_calls) == 1, "No unique recorded author call."
        assert read(Path(author_calls[0]["artifact"]) / "input.json") == payload, (
            "Frozen author input differs from actual call input."
        )
    except AssertionError as exc:
        details.update(available=False, reason=str(exc))
    else:
        details["available"] = True
    return payload, details


def main(output):
    # The campaign publishes this only after its final worker and original-file check.
    verification = read(OUT / "original-verification.json")
    assert verification["changed"] == [], "Campaign original-file verification failed."
    plan = read(OUT / "plan.json")
    for path, expected in plan["frozen_files"].items():
        assert sha(path) == expected, path
    for path, expected in read(OUT / "code-freeze.json").items():
        assert sha(path) == expected, path
    pack, labels = read(OUT / "fresh-sources/sources.json"), read(OUT / "fresh-sources/labels.json")
    assert sha(OUT / "fresh-sources/sources.json") == labels["sources_file_sha256"]
    source_versions = {source["id"]: source for source in pack["source_versions"]}
    labels_by_id = {label["id"]: label for label in labels["cases"]}
    calls_hash = sha(OUT / "calls.json")
    calls = read(OUT / "calls.json")
    assert [call["ordinal"] for call in calls] == list(range(1, len(calls) + 1))
    assert len(calls) <= plan["max_news_cli_calls"]
    expected_labels = ["observed-bad", "inherited-bad", "positive-control"]
    expected_labels += [
        f"{case['id']}-prior-{index}"
        for case in pack["cases"]
        for index, _ in enumerate(case["prior_groups"])
    ]
    expected_labels += [
        f"{case}-{arm}"
        for case in ("ship-cat", "cat-followup", "C01", "C02", "C03", "headlines")
        for arm in ("baseline", "candidate")
    ]
    receipts, receipt_errors = {}, {}
    for label in expected_labels:
        path = OUT / "receipts" / f"{label}.json"
        try:
            value = read(path)
            assert value["label"] == label and value["status"] in {"completed", "failed"}
            assert type(value["accepted"]) is bool and seconds(value["wall_seconds"])
        except (OSError, ValueError, KeyError, TypeError, AssertionError) as exc:
            receipt_errors[label] = f"No complete receipt: {type(exc).__name__}: {exc}"
        else:
            receipts[label] = value
    groups = {
        arm: {
            "cases": {status: [] for status in ("succeeded", "rejected", "failed", "unavailable")},
            "confirmed_starts": 0,
            "unknown_launch_calls": 0,
            "unknown_usage_calls": 0,
            "known_usage": {key: 0 for key in TOKENS},
            "unknown_usage_fields": {key: 0 for key in TOKENS},
            "case_wall_seconds": 0,
            "cli_wall_seconds": 0,
            "unknown_cli_wall_calls": 0,
        }
        for arm in ("baseline", "candidate", "shared_preparation", "controls")
    }
    case_status = {}
    for label in expected_labels:
        receipt = receipts.get(label)
        status = outcome(receipt)
        groups[group(label)]["cases"][status].append(label)
        case_status[label] = {
            "outcome": status,
            "receipt": receipt,
            "unavailable_reason": receipt_errors.get(label),
        }
        if receipt:
            groups[group(label)]["case_wall_seconds"] += receipt["wall_seconds"]
    call_rows, unreceipted = [], []
    for call in calls:
        if call["label"] not in receipts:
            unreceipted.append({key: call[key] for key in ("ordinal", "label", "status")})
            continue  # Never inspect artifacts for a worker without a complete receipt.
        arm = groups[group(call["label"])]
        metadata = call.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        started = metadata.get("process_started")
        if type(started) is not bool:
            started = None
        arm["confirmed_starts"] += started is True
        arm["unknown_launch_calls"] += started is None
        usage = metadata.get("usage")
        if not isinstance(usage, dict) or any(
            type(value) is not int or value < 0 for value in usage.values()
        ):
            usage = None
        arm["unknown_usage_calls"] += started is True and usage is None
        for key in TOKENS:
            arm["unknown_usage_fields"][key] += started is True and (
                usage is None or key not in usage
            )
        for key, value in (usage or {}).items():
            arm["known_usage"][key] = arm["known_usage"].get(key, 0) + value
        wall = call.get("wall_seconds")
        if seconds(wall):
            arm["cli_wall_seconds"] += wall
        else:
            arm["unknown_cli_wall_calls"] += 1
        call_rows.append(
            {
                key: call.get(key)
                for key in ("ordinal", "label", "task", "artifact", "status", "wall_seconds")
            }
            | {"process_started": started, "usage": usage}
        )
    fresh, contexts = [], {}
    for case in pack["cases"]:
        for arm in ("baseline", "candidate"):
            name = f"{case['id']}-{arm}"
            receipt = receipts.get(name)
            assignments, payload, journal = {}, None, None
            context = {"available": False, "reason": "No complete case receipt."}
            if receipt:
                payload, context = fixed_context(case, source_versions, receipt, calls)
            contexts[name] = payload
            unavailable = context.get("reason") if not context["available"] else None
            if receipt and receipt["accepted"]:
                assignments, actual, journal = assignment_rows(receipt)
                assert payload == actual, name
                for article in payload["prior_sources"]:
                    for key in ("story_id", "event_id", "capture_id"):
                        assert assignments[article["id"]][key] == article[key], (
                            name,
                            article["id"],
                            key,
                        )
            else:
                unavailable = (
                    unavailable or f"Case {outcome(receipt)}; no accepted output to score."
                )
            row = {
                "case": case["id"],
                "arm": arm,
                "outcome": outcome(receipt),
                "context": context,
                "journal": journal,
            }
            for kind in ("story", "event"):
                pairs, excluded = labeled_pairs(
                    labels_by_id[case["id"]], set(case["current_source_ids"]), kind
                )
                row[kind] = score_pairs(pairs, assignments, kind, unavailable)
                row[kind]["excluded_prior_prior_pairs"] = excluded
            row["unscored_event_labels"] = labels_by_id[case["id"]]["event_identity"].get(
                "unscored", []
            )
            fresh.append(row)
        baseline, candidate = (contexts[f"{case['id']}-{arm}"] for arm in ("baseline", "candidate"))
        if baseline is not None and candidate is not None:
            assert baseline == candidate, f"{case['id']}: author inputs differ between arms"
    regressions = []
    for arm in ("baseline", "candidate"):
        for case in ("ship-cat", "cat-followup"):
            receipt = receipts.get(f"{case}-{arm}")
            assignments, payload, journal = {}, None, None
            if receipt and receipt["accepted"]:
                assignments, payload, journal = assignment_rows(receipt)
                if case == "ship-cat":
                    assert payload == read(OUT / "inputs/observed-bad-original-input.json")
            pairs = (
                [
                    {"source_ids": [SHIP_NOS, SHIP_BBC], "expected": "same"},
                    {"source_ids": [SHIP_NOS, CAT_BBC], "expected": "different"},
                    {"source_ids": [SHIP_BBC, CAT_BBC], "expected": "different"},
                ]
                if case == "ship-cat"
                else [
                    {"source_ids": [CAT_FOLLOWUP, CAT_BBC], "expected": "same"},
                    {"source_ids": [CAT_FOLLOWUP, SHIP_NOS], "expected": "different"},
                    {"source_ids": [CAT_FOLLOWUP, SHIP_BBC], "expected": "different"},
                ]
            )
            regressions.append(
                {
                    "case": case,
                    "arm": arm,
                    "outcome": outcome(receipt),
                    "journal": journal,
                    "supplied_prior_ids": sorted(
                        article["id"] for article in payload["prior_sources"]
                    )
                    if payload
                    else None,
                    "story": score_pairs(
                        pairs,
                        assignments,
                        "story",
                        None
                        if receipt and receipt["accepted"]
                        else f"Case {outcome(receipt)}; no accepted output.",
                    ),
                }
            )
    controls = [
        {
            "label": label,
            "expected": "succeeded" if label == "positive-control" else "rejected",
            "observed": outcome(receipts.get(label)),
            "matches_expectation": outcome(receipts.get(label))
            == ("succeeded" if label == "positive-control" else "rejected"),
        }
        for label in ("observed-bad", "inherited-bad", "positive-control")
    ]
    for values in groups.values():
        values["case_counts"] = {key: len(value) for key, value in values["cases"].items()}
        for key in ("case_wall_seconds", "cli_wall_seconds"):
            values[key] = round(values[key], 6)
    totals = {
        key: sum(values[key] for values in groups.values())
        for key in (
            "confirmed_starts",
            "unknown_launch_calls",
            "unknown_usage_calls",
            "case_wall_seconds",
            "cli_wall_seconds",
            "unknown_cli_wall_calls",
        )
    }
    totals["known_usage"] = {
        key: sum(values["known_usage"].get(key, 0) for values in groups.values())
        for key in sorted({key for values in groups.values() for key in values["known_usage"]})
    }
    fresh_totals = {
        arm: {
            kind: {
                expected: {
                    status: sum(
                        row[kind]["counts"][expected][status] for row in fresh if row["arm"] == arm
                    )
                    for status in ("correct", "wrong", "unavailable")
                }
                for expected in ("same", "different")
            }
            for kind in ("story", "event")
        }
        for arm in ("baseline", "candidate")
    }
    result = {
        "method": "Offline script authored by an implementation agent, not an independent endorsement. No overall accuracy percentage. Frozen source-only labels are targeted judgments, not verified real-world truth.",
        "scope": "Paired arm costs exclude shared preparation and review controls, which are reported separately. Succeeded means committed operational output, not semantic success. Story/event pair results are separate; event labels are never inferred from story labels. Prior-prior fresh pairs are excluded.",
        "not_scored": "Reader-answer omissions, attribution/scope and headline semantic adequacy require the separate final review; this script does not infer them from IDs or lexical matching. Original ship/cat regressions are retrospective; fresh labels precede their outputs.",
        "script_sha256": sha(Path(__file__)),
        "calls_sha256": calls_hash,
        "sources_sha256": sha(OUT / "fresh-sources/sources.json"),
        "labels_sha256": sha(OUT / "fresh-sources/labels.json"),
        "max_cli_calls": plan["max_news_cli_calls"],
        "recorded_call_attempts": len(calls),
        "groups": groups,
        "totals": totals,
        "cases": case_status,
        "calls": call_rows,
        "unreceipted_calls": unreceipted,
        "fresh_pairs": fresh,
        "fresh_pair_totals_by_arm": fresh_totals,
        "original_regressions": regressions,
        "controls": controls,
        "original_file_verification": verification,
    }
    assert sha(OUT / "calls.json") == calls_hash, "Call ledger changed during measurement."
    output = output.resolve()
    assert output.is_relative_to(OUT), (
        "Metrics output must remain inside the experiment audit directory."
    )
    with output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    print(
        json.dumps(
            {"metrics": str(output), "recorded_call_attempts": len(calls), "groups": groups},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=OUT / "metrics.json")
    main(parser.parse_args().output)
