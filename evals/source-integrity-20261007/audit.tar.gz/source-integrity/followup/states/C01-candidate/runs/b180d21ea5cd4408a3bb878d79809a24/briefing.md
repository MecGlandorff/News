# News — observed on 2026-05-18

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Musk’s lawsuit over OpenAI’s commercial transformation](stories/s-dc4153759149a0628ffc.md)

### Musk loses lawsuit after finding that he waited too long to sue

**New development** — NOS and BBC report that Musk lost his lawsuit over OpenAI’s commercial transformation because the jury found he waited too long to sue. NOS adds that the nine-member jury was advisory and the judge adopted its finding.

[NOS](<https://nos.nl/l/2614904>) · published 2026-05-18T19:58:18+02:00 · observed on 2026-05-18
Capture `c-49e0f4a353c9c1900408ca20` · Article text

> Elon Musk heeft de rechtszaak die hij tegen OpenAI aanspande verloren. De miljardair had het bedrijf van topman Sam Altman voor de rechter gesleept omdat hij er geld aan doneerde en het er niet mee eens is dat het een bedrijf is geworden dat winst maakt in plaats van een non-profit onderzoeksbedrijf.

[NOS](<https://nos.nl/l/2614904>) · published 2026-05-18T19:58:18+02:00 · observed on 2026-05-18
Capture `c-49e0f4a353c9c1900408ca20` · Article text

> Een negenkoppige jury oordeelde dat Musk te lang heeft gewacht met het beginnen van een rechtszaak. De jury had slechts een adviserende rol, maar de rechter nam hun oordeel over.

[BBC News](<https://www.bbc.com/news/articles/cewpyv79pw1o?at_medium=RSS&at_campaign=rss>) · published 2026-05-18T20:59:57+00:00 · observed on 2026-05-18
Capture `c-98b4effea00ae50859f76421` · Headline

> Musk loses OpenAI court battle after jury finds he waited too long to sue

Earlier source supporting this story/event link:

[NOS](<https://nos.nl/l/2612416>) · published 2026-04-29T16:25:56+02:00 · observed on 2026-04-29
Capture `c-d040f7366d2e0e5d7e1f8838` · Article text

> Met de rechtszaak wil Musk bereiken dat OpenAI's aanpassing naar een op winst gericht bedrijf wordt teruggedraaid.
