# News — observed on 2026-04-29

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Musk’s lawsuit over OpenAI’s commercial transformation and requested relief](stories/s-dc4153759149a0628ffc.md)

### Differing reports of Musk’s monetary demand in the OpenAI lawsuit

**Unresolved disagreement** — BBC described Musk as seeking more than $130bn in damages. NOS says he requests no specific amount and previously had allegedly unlawful profits estimated at $78bn–$134bn, with those profits to go to OpenAI’s nonprofit arm. These accounts differ on whether he seeks a specified amount; NOS does not explicitly correct BBC or establish a subsequent change in his demand.

**Unresolved in this reporting:** Does Musk’s requested relief specify an amount, or does the reported figure refer only to an estimate of allegedly unlawful profits?

[NOS](<https://nos.nl/l/2612416>) · published 2026-04-29T16:25:56+02:00 · observed on 2026-04-29
Capture `c-d040f7366d2e0e5d7e1f8838` · Article text

> Met de rechtszaak wil Musk bereiken dat OpenAI's aanpassing naar een op winst gericht bedrijf wordt teruggedraaid. Ook wil hij dat "alle onrechtmatig verkregen winst" terechtkomt bij het non-profitonderdeel van OpenAI.

[NOS](<https://nos.nl/l/2612416>) · published 2026-04-29T16:25:56+02:00 · observed on 2026-04-29
Capture `c-d040f7366d2e0e5d7e1f8838` · Article text

> Musk vraagt niet om een specifiek bedrag, maar liet de onrechtmatig verkregen winst eerder schatten op 78 miljard tot 134 miljard dollar.

Compared assertion (preserved with its attribution):

[BBC News](<https://www.bbc.com/news/videos/ckger3y52k2o?at_medium=RSS&at_campaign=rss>) · published 2026-04-27T14:12:09+00:00 · observed on 2026-04-27
Capture `c-a48c62328b6de1725423dc9f` · Article text

> Musk, who co-founded the company that created ChatGPT with Altman, wants more than $130bn in damages.

## [OpenAI’s failure to alert authorities before the Tumbler Ridge shooting](stories/s-8b9ff537eb77b5761dc4.md)

### Victims’ families file negligence lawsuits over OpenAI’s failure to alert authorities

**New development** — The Guardian reports that families of seven victims filed negligence lawsuits against OpenAI and its CEO on Wednesday, April 29, over the failure to alert authorities before the Tumbler Ridge shooting, the same failure addressed by Altman’s earlier apology. The lawsuits allege employees flagged the shooter’s account eight months before the attack and identified a credible, specific threat of gun violence.

[The Guardian](<https://www.theguardian.com/technology/2026/apr/29/openai-tumbler-ridge-shooter-chatgpt-lawsuit>) · published 2026-04-29T13:00:49+00:00 · observed on 2026-04-29
Capture `c-9f249b0c44bc90ea8a219e1d` · Article text

> New lawsuits allege employees urged company to notify authorities months before deadly Tumbler Ridge attack

[The Guardian](<https://www.theguardian.com/technology/2026/apr/29/openai-tumbler-ridge-shooter-chatgpt-lawsuit>) · published 2026-04-29T13:00:49+00:00 · observed on 2026-04-29
Capture `c-9f249b0c44bc90ea8a219e1d` · Article text

> Families of seven victims of a mass shooting at a secondary school in British Columbia are suing OpenAI and the company’s CEO for negligence after it failed to alert authorities to the shooter’s troubling conversations with ChatGPT.

[The Guardian](<https://www.theguardian.com/technology/2026/apr/29/openai-tumbler-ridge-shooter-chatgpt-lawsuit>) · published 2026-04-29T13:00:49+00:00 · observed on 2026-04-29
Capture `c-9f249b0c44bc90ea8a219e1d` · Article text

> The lawsuits, filed on Wednesday in a federal court in San Francisco, allege that the violent intentions of the shooter, identified as 18-year-old Jesse Van Rootselaar, were well-known to OpenAI. Employees at the company flagged the shooter’s account eight months before the attack and determined that it posed “a credible and specific threat of gun violence against real people”, according to the lawsuit.

Earlier source supporting this story/event link:

[The Guardian](<https://www.theguardian.com/us-news/2026/apr/25/altman-apologizes-after-openai-failed-to-alert-police-before-fatal-canada-shooting>) · published 2026-04-25T02:13:21+00:00 · observed on 2026-04-27
Capture `c-364676b1da09f6d9792b04b4` · Article text

> The head of OpenAI has written a letter apologizing that his company didn’t alert law enforcement about the online behavior of a person who shot and killed eight people in Tumbler Ridge, British Columbia.
