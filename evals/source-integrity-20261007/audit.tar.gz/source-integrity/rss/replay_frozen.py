"""Offline parser/queue audit. Original feeds and manifests are read-only inputs."""

import hashlib
import json
import sys
import types
import xml.etree.ElementTree as ET
from datetime import datetime
from html.parser import HTMLParser
from io import BytesIO
from pathlib import Path
from unittest.mock import patch


REPO = Path(__file__).resolve().parents[3]
PRIMARY = Path("/Users/mrgreen/Desktop/AI/News-worktrees/from-scratch")
OUTPUT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from news import daily, feeds  # noqa: E402
from news.domain import digest  # noqa: E402


def no_external_calls(event, args):
    if event.startswith("socket.") or event == "subprocess.Popen":
        raise AssertionError(f"External call forbidden in this audit: {event}")


sys.addaudithook(no_external_calls)
assert Path(feeds.__file__).resolve() == REPO / "news/feeds.py"
original_parser_path = PRIMARY / "news/feeds.py"
original_parser = types.ModuleType("original_feeds_for_audit")
exec(compile(original_parser_path.read_text(), str(original_parser_path), "exec"), vars(original_parser))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class DescriptionText(HTMLParser):
    """Independent normalization of the known plain RSS description fixtures."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_starttag(self, tag, attrs):
        assert tag not in {"script", "style"}
        self.parts.append(" ")

    def handle_endtag(self, tag):
        self.parts.append(" ")

    def handle_data(self, data):
        self.parts.append(data)


def expected_description(item):
    field = item.find("description")
    assert field is not None and field.text
    parser = DescriptionText()
    parser.feed(field.text)
    result = " ".join("".join(parser.parts).split())
    assert result
    return result


def metadata(article):
    return {key: value for key, value in article.items() if key != "text"}


manifest_paths = sorted((PRIMARY / ".news/dogfood/captures").glob("*/manifest.json"))
assert len(manifest_paths) == 3
input_paths = [original_parser_path] + [
    path
    for manifest in manifest_paths
    for path in [manifest, manifest.parent / "feeds/collection.json"]
    + sorted((manifest.parent / "feeds").glob("feed-*.xml"))
]
before = {str(path): sha256(path) for path in input_paths}
candidate_state = OUTPUT / "candidate-captures-complete"
candidate_state.mkdir()
candidate_manifests = []
old_versions = {}
result = {
    "scope": "All nine raw feed files from three frozen polls, actual collect and daily _capture; no model/story processing.",
    "parser_sha256": sha256(REPO / "news/feeds.py"),
    "script_sha256": sha256(Path(__file__)),
    "input_sha256": before,
    "polls": [],
    "guardian_items_checked": 0,
    "guardian_bodies_recovered": 0,
    "non_guardian_articles_unchanged": 0,
}
for manifest_path in manifest_paths:
    old = json.loads(manifest_path.read_text())
    config = [{key: feed[key] for key in ("name", "url")} for feed in old["coverage"]["feeds"]]
    raw = {
        feed["url"]: (manifest_path.parent / "feeds" / feed["raw_file"]).read_bytes()
        for feed in old["coverage"]["feeds"]
    }
    calls = []

    def offline_feed(request, **kwargs):
        calls.append(request.full_url)
        return BytesIO(raw[request.full_url])

    with patch.object(feeds, "urlopen", offline_feed):
        candidate = daily._capture(
            config,
            candidate_state,
            candidate_manifests,
            datetime.fromisoformat(old["captured_at"]),
            old["batch_size"],
        )
    assert calls == [feed["url"] for feed in config]
    assert len(candidate["articles"]) == len(old["articles"])
    assert sorted(digest(metadata(a)) for a in candidate["articles"]) == sorted(
        digest(metadata(a)) for a in old["articles"]
    )
    for field in ("accepted", "invalid", "future", "duplicates", "feed_errors", "status"):
        assert candidate["coverage"][field] == old["coverage"][field]
    guardian_feed = old["coverage"]["feeds"][2]
    guardian_items = ET.fromstring(raw[guardian_feed["url"]]).findall("./channel/item")
    descriptions = {item.findtext("link"): expected_description(item) for item in guardian_items}
    assert len(guardian_items) == len(descriptions) == 45
    original_by_key = {digest(metadata(article)): article for article in old["articles"]}
    assert len(original_by_key) == len(old["articles"])
    old_new = {
        key
        for key, article in original_by_key.items()
        if digest(article) not in old_versions.get((article["source"], article["url"]), set())
    }
    assert len(old_new) == old["new_versions"]
    candidate_new = {
        digest(metadata(article))
        for article in candidate["articles"]
        if digest(article) in candidate["processing_ids"]
    }
    poll = {
        "original_capture": old["id"],
        "candidate_capture": candidate["id"],
        "captured_articles": len(candidate["articles"]),
        "original_new_versions": old["new_versions"],
        "candidate_new_versions": candidate["new_versions"],
        "guardian_bodies": [],
        "added_version_selection": [original_by_key[key]["url"] for key in sorted(candidate_new - old_new)],
        "removed_version_selection": [original_by_key[key]["url"] for key in sorted(old_new - candidate_new)],
        "fetch_exact_day": [],
    }
    for article in candidate["articles"]:
        original = original_by_key[digest(metadata(article))]
        assert metadata(article) == metadata(original)
        if article["source"] == guardian_feed["name"]:
            result["guardian_items_checked"] += 1
            assert article["text"] == descriptions[article["url"]]
            assert article["text"] != original["text"]
            result["guardian_bodies_recovered"] += 1
            poll["guardian_bodies"].append({
                "url": article["url"],
                "original_digest": digest(original),
                "candidate_digest": digest(article),
                "description_text_sha256": hashlib.sha256(article["text"].encode()).hexdigest(),
                "description_characters": len(article["text"]),
                "other_fields_unchanged": True,
            })
        else:
            assert article == original
            result["non_guardian_articles_unchanged"] += 1
    for feed in config:
        parsed, stats = feeds.parse_feed(raw[feed["url"]], feed["name"], feed["url"], old["day"], 50)
        baseline, baseline_stats = original_parser.parse_feed(
            raw[feed["url"]], feed["name"], feed["url"], old["day"], 50
        )
        assert stats == baseline_stats
        assert [metadata(article) for article in parsed] == [metadata(article) for article in baseline]
        if feed["name"] != guardian_feed["name"]:
            assert parsed == baseline
        else:
            assert all(article["text"] == descriptions[article["url"]] for article in parsed)
        poll["fetch_exact_day"].append({"source": feed["name"], "accepted": len(parsed), "stats": stats})
    candidate_manifests.append(candidate)
    old_versions.update(daily._versions(old["articles"]))
    result["polls"].append(poll)

assert [poll["candidate_new_versions"] for poll in result["polls"]] == [97, 81, 83]
assert [poll["original_new_versions"] for poll in result["polls"]] == [97, 80, 82]
assert result["guardian_items_checked"] == result["guardian_bodies_recovered"] == 135
assert all(not poll["removed_version_selection"] for poll in result["polls"])
assert [len(poll["added_version_selection"]) for poll in result["polls"]] == [0, 1, 1]
assert before == {str(path): sha256(path) for path in input_paths}
result["original_inputs_unchanged"] = True
result["network_calls"] = result["model_calls"] = 0
with (OUTPUT / "frozen-replay.json").open("x", encoding="utf-8") as handle:
    json.dump(result, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps({key: value for key, value in result.items() if key not in {"input_sha256", "polls"}}, indent=2))
for poll in result["polls"]:
    print(json.dumps({key: value for key, value in poll.items() if key != "guardian_bodies"}, indent=2))
