# News — observed on 2026-04-30

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Proposed parliamentary inquiry into Starmer over Mandelson’s appointment](stories/s-d19596f299e30b4f654f.md)

### Motion for parliamentary inquiry fails to win a majority

**New development** — Telegraaf reports that the motion for an inquiry failed to secure a parliamentary majority. The proposed inquiry would have examined whether Starmer misled the Commons over Mandelson’s appointment as US ambassador.

[Telegraaf](<https://www.telegraaf.nl/buitenland/geen-parlementair-onderzoek-naar-starmer-om-aanstelling-mandelson/150070346.html>) · published 2026-04-28T17:45:45+00:00 · observed on 2026-04-30
Capture `c-352e9d2657d41ccae8d0aa0e` · Article text

> Er komt geen parlementair onderzoek naar de Britse premier Keir Starmer. In het parlement wist de motie hiervoor geen meerderheid te behalen. Uit het onderzoek had duidelijk moeten worden of de sociaaldemocraat Starmer het Lagerhuis mogelijk bewust of onbewust heeft misleid in de affaire rond de benoeming van Peter Mandelson als ambassadeur in de Verenigde Staten.

Earlier source supporting this story/event link:

[BBC News](<https://www.bbc.com/news/articles/c3r3r2vzjp1o?at_medium=RSS&at_campaign=rss>) · published 2026-04-27T17:47:42+00:00 · observed on 2026-04-27
Capture `c-7f289d8bafdc192d06332212` · Headline

> Starmer faces vote on inquiry over Mandelson vetting claims

## [Trial over May 2025 arson attacks on property linked to Starmer](stories/s-6908ef34a3f7aacf041f.md)

### Court hears allegations about recruitment for the Starmer arson attacks

**New development** — NYT reports that jurors were told the defendants were recruited through a Russian-language Telegram account for attacks on two buildings and a car linked to Starmer last year. BBC reports that the court heard a man offered Ukrainians money to carry out the attacks and identifies three accused men.

[NYT](<https://www.nytimes.com/2026/04/29/world/europe/arson-keir-starmer-homes.html>) · published 2026-04-29T16:20:11+00:00 · observed on 2026-04-30
Capture `c-b84a8508775c9ffda70949d8` · Article text

> Two buildings and a car linked to Prime Minister Keir Starmer of Britain were set afire last year. The men on trial for it were recruited through a Russian-language Telegram account, a jury was told.

[BBC News](<https://www.bbc.com/news/articles/cx21y204zz4o?at_medium=RSS&at_campaign=rss>) · published 2026-04-29T15:01:41+00:00 · observed on 2026-04-30
Capture `c-cd4613d859a8e847d1d44523` · Headline

> Man offered Ukrainians money to carry out Starmer arson attacks, court hears

[BBC News](<https://www.bbc.com/news/articles/cx21y204zz4o?at_medium=RSS&at_campaign=rss>) · published 2026-04-29T15:01:41+00:00 · observed on 2026-04-30
Capture `c-cd4613d859a8e847d1d44523` · Article text

> The three men are accused of targeting north London properties linked to Prime Minister Sir Keir Starmer.

### Court hears sister-in-law’s account of the Kentish Town arson attack

**New development** — The Guardian reports that the court heard Judith Alexander feared what might have happened had she not woken during the attack on her home, a Kentish Town house owned by Starmer. It links the incident to the May 2025 series of attacks and reports that the three accused men deny all charges.

[The Guardian](<https://www.theguardian.com/uk-news/2026/apr/30/starmers-sister-in-law-feared-what-might-have-happened-in-arson-attack-court-hears>) · published 2026-04-30T20:56:50+00:00 · observed on 2026-04-30
Capture `c-7f4f98851d708c8456ba7a10` · Article text

> Judith Alexander describes how Kentish Town house owned by the prime minister was targeted
> The prime minister’s sister-in-law has said she feared what might have happened had she not woken up after her home was targeted in an arson attack, a court has heard.
> The incident is one of a series of arson attacks that took place in May last year on property linked to Keir Starmer, which three men with links to Ukraine are accused of targeting. They deny all the charges.
