# News — observed on 2026-10-07

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [BBC appoints Rachel Jupp as director of news](stories/s-518629023995429cea9b.md)

### Rachel Jupp appointed BBC news director

**New development** — BBC News reports that the BBC has appointed Rachel Jupp as its new director of news.

[BBC News](<https://www.bbc.co.uk/news/articles/cjrvl8n82wvo?at_campaign=rss&at_medium=RSS>) · published 2026-10-05T13:05:13+00:00 · observed on 2026-10-07
Capture `c-2916ced2e63d8fdc8940455f` · Headline

> BBC appoints Rachel Jupp as new director of news

## [Pentagon's exclusion of Anthropic AI tools](stories/s-80f38dea272165b2f2eb.md)

### Pentagon reportedly stops using Anthropic tools after blacklisting

**New development** — BBC News reports being told that the Pentagon has stopped using Anthropic AI tools, following its February designation of the company as a supply chain risk after it refused to remove safety guardrails.

[BBC News](<https://www.bbc.co.uk/news/articles/c5j9x9pr0240o?at_campaign=rss&at_medium=RSS>) · published 2026-10-05T16:13:21+00:00 · observed on 2026-10-07
Capture `c-7d2c2227bd31cf28896c8bdf` · Headline

> Pentagon stops using Anthropic AI tools after blacklisting company, BBC told

[BBC News](<https://www.bbc.co.uk/news/articles/c5j9x9pr0240o?at_campaign=rss&at_medium=RSS>) · published 2026-10-05T16:13:21+00:00 · observed on 2026-10-07
Capture `c-7d2c2227bd31cf28896c8bdf` · Article text

> It labelled Anthropic a "supply chain risk" in February after the firm refused to remove safety guardrails from its tools.

## [Benjamin William Day's murder of Maria Saceanu](stories/s-e37eeb993b20f2019aa9.md)

### Student admits murdering Maria Saceanu

**New development** — BBC News reports that a student admits murder; its text identifies him as Benjamin William Day, 20, who lured Maria Saceanu to an Airbnb to murder her.

[BBC News](<https://www.bbc.co.uk/news/articles/c6x2v8x72g4ko?at_campaign=rss&at_medium=RSS>) · published 2026-10-06T16:19:56+00:00 · observed on 2026-10-07
Capture `c-6a35ea4c470e0cbf57ef8beb` · Headline

> Student admits murdering woman in 'Dexter' kill room

[BBC News](<https://www.bbc.co.uk/news/articles/c6x2v8x72g4ko?at_campaign=rss&at_medium=RSS>) · published 2026-10-06T16:19:56+00:00 · observed on 2026-10-07
Capture `c-6a35ea4c470e0cbf57ef8beb` · Article text

> Forensics student Benjamin William Day, 20, lured Maria Saceanu to an Airbnb to murder her.

## [Boots sale to Canadian billionaire family](stories/s-581e8a2a9e8f321c1eaf.md)

### £7bn Boots sale announced

**New development** — BBC News reports a £7bn sale of Boots to a Canadian billionaire family, with the sale announced on Wednesday.

[BBC News](<https://www.bbc.co.uk/news/articles/cwly0jyk2vl5o?at_campaign=rss&at_medium=RSS>) · published 2026-10-07T17:18:30+00:00 · observed on 2026-10-07
Capture `c-378df0ec4dfdb2fd36bd79c0` · Headline

> Boots sold in £7bn deal to Canadian billionaire family

[BBC News](<https://www.bbc.co.uk/news/articles/cwly0jyk2vl5o?at_campaign=rss&at_medium=RSS>) · published 2026-10-07T17:18:30+00:00 · observed on 2026-10-07
Capture `c-378df0ec4dfdb2fd36bd79c0` · Article text

> The sale of the High Street chain was announced on Wednesday.
