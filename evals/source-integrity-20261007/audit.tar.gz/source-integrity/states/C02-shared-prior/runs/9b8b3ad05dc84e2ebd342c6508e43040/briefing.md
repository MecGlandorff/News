# News — observed on 2026-04-27

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Proposed inquiry vote over Mandelson vetting claims](stories/s-d19596f299e30b4f654f.md)

### No 10 reaction to Conservative-requested vote

**Event identity uncertain; kept separate.**

**Change unclear** — BBC reports that No 10 called the Conservative-requested move a political stunt. The excerpt does not identify the vote's timing or precise subject sufficiently to establish the occurrence or what changed.

[BBC News](<https://www.bbc.com/news/articles/c3r3r2vzjp1o?at_medium=RSS&at_campaign=rss>) · published 2026-04-27T17:47:42+00:00 · observed on 2026-04-27
Capture `c-7f289d8bafdc192d06332212`

> No 10 brands the move "a desperate political stunt by the Conservative Party", which had asked for the vote.
