# Southern Water alleged water quality test manipulation case

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

First observed 2026-07-22 · latest observation 2026-07-22

## Observed on 2026-07-22

### Former Southern Water boss among four charged

**New development** — BBC reports that former Southern Water boss Matthew Wright and three others have been charged over an alleged plan to manipulate water quality tests to save the firm millions in penalties.

[BBC News](<https://www.bbc.co.uk/news/articles/c36d0njy7jjo?at_medium=RSS&at_campaign=rss>) · published 2026-07-22T16:07:15+00:00 · observed on 2026-07-22
Capture `c-70ccab3f30c1f1f5a464b464` · Headline

> Ex-Southern Water boss among four charged over alleged plan to manipulate water quality tests

[BBC News](<https://www.bbc.co.uk/news/articles/c36d0njy7jjo?at_medium=RSS&at_campaign=rss>) · published 2026-07-22T16:07:15+00:00 · observed on 2026-07-22
Capture `c-70ccab3f30c1f1f5a464b464` · Article text

> Matthew Wright is accused alongside three others of trying to save the firm millions in penalties.
