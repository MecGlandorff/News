# Matthew Wright and three others accused over avoiding firm penalties

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

First observed 2026-07-22 · latest observation 2026-07-22

## Observed on 2026-07-22

### Accusations against Matthew Wright and three others

**Change unclear** — BBC reports that Matthew Wright and three others are accused of trying to save the firm millions in penalties. The excerpt does not establish when the accusations were made or what procedural development occurred.

[BBC News](<https://www.bbc.co.uk/news/articles/c36d0njy7jjo?at_medium=RSS&at_campaign=rss>) · published 2026-07-22T16:07:15+00:00 · observed on 2026-07-22
Capture `c-70ccab3f30c1f1f5a464b464`

> Matthew Wright is accused alongside three others of trying to save the firm millions in penalties.
