# News — observed on 2026-07-22

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [England bus fare cap policy](stories/s-e9961f01e7cdca88935c.md)

### Government statement on the fare cap policy

**Event identity uncertain; kept separate.**

**Change unclear** — BBC reports the government's claim that the policy will ease living costs. The excerpt does not establish the policy's details or the announcement occurrence.

[BBC News](<https://www.bbc.co.uk/news/articles/cz64l78n5vpo?at_medium=RSS&at_campaign=rss>) · published 2026-07-22T12:26:03+00:00 · observed on 2026-07-22
Capture `c-e695306f9918096709e8a555`

> The government says the policy will "help with the cost of living and give people the breathing space they need"

## [Matthew Wright and three others accused over avoiding firm penalties](stories/s-f67f88b5f7c4ab072ced.md)

### Accusations against Matthew Wright and three others

**Change unclear** — BBC reports that Matthew Wright and three others are accused of trying to save the firm millions in penalties. The excerpt does not establish when the accusations were made or what procedural development occurred.

[BBC News](<https://www.bbc.co.uk/news/articles/c36d0njy7jjo?at_medium=RSS&at_campaign=rss>) · published 2026-07-22T16:07:15+00:00 · observed on 2026-07-22
Capture `c-70ccab3f30c1f1f5a464b464`

> Matthew Wright is accused alongside three others of trying to save the firm millions in penalties.

## [Reported autonomous AI cyber-attack disclosed by OpenAI](stories/s-90200b2d5b600d7a3b9f.md)

### Reported cyber-attack without direct human involvement

**Change unclear** — BBC describes the attack as one of the first publicly disclosed cyber-attacks carried out by AI without direct human involvement. The excerpt supplies no occurrence date or basis for determining what changed.

[BBC News](<https://www.bbc.co.uk/news/articles/c3ek3gvdnj3o?at_medium=RSS&at_campaign=rss>) · published 2026-07-22T11:40:11+00:00 · observed on 2026-07-22
Capture `c-f7b2129f3eb03cdff5712c7e`

> It is one of the first publicly disclosed cyber-attacks carried out by AI without direct human involvement.
