# News — observed on 2026-10-05

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Royad Mammadov fatal Black Sea ship incident](stories/s-cf8a63c0238048a72e7d.md)

### Cargo ship sinks after fire; Zelensky alleges Russian attack

**New development** — NOS reports Romania's account of two deaths and 11 rescued after a Black Sea cargo ship fire and sinking. NOS identifies the vessel as Royad Mammadov through Romania's maritime authority. Zelensky alleges a Russian drone attack on a Turkish corn carrier; BBC likewise attributes the captain's death and 11 rescues to Ukraine's leader. Reporting the captain's death does not contradict the Romanian total of two deaths.

[NOS](<https://nos.nl/l/2633775>) · published 2026-10-05T15:22:56+00:00 · observed on 2026-10-05
Capture `c-0bc3511c09efd3d460f9947b`

> Twee mensen zijn omgekomen bij een brand aan boord van een vrachtschip op de Zwarte Zee, meldt Roemenië. Het schip is gezonken, elf bemanningsleden zijn gered.

[NOS](<https://nos.nl/l/2633775>) · published 2026-10-05T15:22:56+00:00 · observed on 2026-10-05
Capture `c-0bc3511c09efd3d460f9947b`

> De Oekraïense president Zelensky doet dat wel. Hij beschuldigt Rusland van een droneaanval op een Turks schip dat maïs vervoerde.

[NOS](<https://nos.nl/l/2633775>) · published 2026-10-05T15:22:56+00:00 · observed on 2026-10-05
Capture `c-0bc3511c09efd3d460f9947b`

> Volgens de Roemeense maritieme autoriteit gaat het om het schip de Royad Mammadov.

[BBC News](<https://www.bbc.co.uk/news/articles/cr0j0w3p8453o?at_campaign=rss&at_medium=RSS>) · published 2026-10-05T15:17:23+00:00 · observed on 2026-10-05
Capture `c-1ded1dc6493a0bda56e4538e`

> The vessel's captain was killed and 11 crew members were rescued after the attack on the Turkish-owned ship, Ukraine's leader says.

## [Alleged theft of 2,700 cats in Ho Chi Minh City](stories/s-c3c6d5978bccf6e0e672.md)

### Men accused of stealing cats for slaughter

**Change unclear** — BBC reports that men are accused of stealing around 2,700 cats in Ho Chi Minh City, allegedly for slaughter as food. The excerpt does not establish the timing or an arrest development.

[BBC News](<https://www.bbc.co.uk/news/articles/c8x234k9epq5o?at_campaign=rss&at_medium=RSS>) · published 2026-10-05T15:10:35+00:00 · observed on 2026-10-05
Capture `c-d94bb6aea4ef0a09af63c8ac`

> The men are accused of stealing around 2,700 cats in Ho Chi Minh City, allegedly to be slaughtered for food.

## [Imran Khan supporters' Islamabad march report](stories/s-99c7beffabae64775345.md)

### Occurrence unverified from photograph credit

**Event identity uncertain; kept separate.**

**Change unclear** — The Guardian capture contains only a photograph credit; it provides no account establishing a march or what changed.

[The Guardian](<https://www.theguardian.com/world/2026/oct/05/jailed-imran-khan-march-on-islamabad-pakistan>) · published 2026-10-05T15:19:46+00:00 · observed on 2026-10-05
Capture `c-0766bca8a0b8909f2aac8056`

> Photograph: Marwat Akbar/AFP/Getty Images

## [Nike's third workforce reduction of 2026 amid weak sales](stories/s-4764fcd205f1c0d72928.md)

### Nike decides on third round of layoffs this year

**New development** — NOS reports that Nike decided to cut jobs for the third time this year because sales are disappointing, citing financial reports. Nike expects revenue to decline by 7–9 percent next year.

[NOS](<https://nos.nl/l/2633780>) · published 2026-10-05T15:35:30+00:00 · observed on 2026-10-05
Capture `c-1cdad43acf87d62bee496838`

> Het sportmerk besloot voor de derde keer dit jaar werknemers te ontslaan omdat de verkoopcijfers behoorlijk tegenvallen, blijkt uit de financiële verslagen. En de voorspellingen voor de toekomst zien er ook niet rooskleurig uit: het bedrijf houdt volgend jaar rekening met een daling van de omzet tussen de 7 en 9 procent.

## [Saudi-led air campaign in Yemen report](stories/s-8e71e02e0bd8b81bf63a.md)

### Campaign occurrence unverified from photograph credit

**Event identity uncertain; kept separate.**

**Change unclear** — The Guardian capture contains only a photograph credit. It does not establish an air campaign occurrence or a connection to the previously reported Operation Dawn of Yemen.

[The Guardian](<https://www.theguardian.com/world/2026/oct/05/yemen-air-campaign-houthis-saudi-led-coalition>) · published 2026-10-05T15:21:54+00:00 · observed on 2026-10-05
Capture `c-c55646f4dd906cc5a2641a91`

> Photograph: Abdulnasser Alseddik/AP

## [Siberian laboratory worker's possible plague death report](stories/s-739528de93e0e8889301.md)

### Occurrence unverified from photograph credit

**Event identity uncertain; kept separate.**

**Change unclear** — The Guardian capture contains only a photograph credit, without reporting establishing a death, its cause or a monitoring development.

[The Guardian](<https://www.theguardian.com/world/2026/oct/05/russia-lab-worker-possibly-dies-of-plague-siberia-quarantine-measures-irkutsk>) · published 2026-10-05T15:36:37+00:00 · observed on 2026-10-05
Capture `c-f33d227285cff9bbfa21c19d`

> Photograph: Social Media

## [Shadow chancellor's proposal to cut building regulations](stories/s-4b528fb1db14c61d6660.md)

### BBC Verify examines construction-cost proposal

**Change unclear** — BBC Verify examines the shadow chancellor's plan to reduce construction costs by cutting some building regulations. The excerpt gives neither findings nor a dated policy development.

[BBC News](<https://www.bbc.co.uk/news/articles/c32l4n8yprglo?at_campaign=rss&at_medium=RSS>) · published 2026-10-05T15:19:46+00:00 · observed on 2026-10-05
Capture `c-1684330e15bb2ea9ebd4800a`

> BBC Verify looks into the shadow chancellor's plan to cut some building regulations to reduce construction costs.
