# News — observed on 2026-10-06

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Investigation into alleged theft of 2,700 cats in Ho Chi Minh City](stories/s-c3c6d5978bccf6e0e672.md)

### Further details of the alleged Ho Chi Minh City cat-theft network

**Additional reporting** — Following BBC's report of accusations involving around 2,700 stolen cats in Ho Chi Minh City, NOS reports that twelve men are suspected of stealing and reselling cats, presumably for consumption, citing state media. NOS identifies 39-year-old Luu Thanh Binh as the suspected leader and reports alleged admissions to stealing 2,700 cats. These are further details of the same allegations; the excerpts do not establish a subsequent development. NOS says the network's duration is unknown.

**Unresolved in this reporting:** How long was the alleged network active?

[NOS](<https://nos.nl/l/2633880>) · published 2026-10-06T13:28:19+00:00 · observed on 2026-10-06
Capture `c-0c3db4bee254d786af1c90a0`

> De Vietnamese politie heeft een netwerk opgerold dat verantwoordelijk is voor de diefstal van duizenden katten in Ho Chi Minh-stad. Twaalf mannen worden verdacht van het stelen en doorverkopen van de dieren, vermoedelijk voor consumptie, melden staatsmedia . De hoofdverdachte is de 39-jarige Luu Thanh Binh, hij is de vermoedelijke bendeleider.

[NOS](<https://nos.nl/l/2633880>) · published 2026-10-06T13:28:19+00:00 · observed on 2026-10-06
Capture `c-0c3db4bee254d786af1c90a0`

> De verdachten zouden tijdens hun verhoor hebben toegegeven in totaal 2700 katten te hebben gestolen. Het is niet bekend hoelang de bende precies actief was.

Compared assertion (preserved with its attribution):

[BBC News](<https://www.bbc.co.uk/news/articles/c8x234k9epq5o?at_campaign=rss&at_medium=RSS>) · published 2026-10-05T15:10:35+00:00 · observed on 2026-10-05
Capture `c-d94bb6aea4ef0a09af63c8ac`

> The men are accused of stealing around 2,700 cats in Ho Chi Minh City, allegedly to be slaughtered for food.
