# News — observed on 2026-04-30

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Parliamentary inquiry proposal over Starmer’s appointment of Mandelson](stories/s-d19596f299e30b4f654f.md)

### Inquiry motion fails to win a parliamentary majority

**New development** — Following the previously reported reaction to the proposed inquiry vote, Telegraaf reports that the motion failed to secure a majority. The proposed inquiry would have examined whether Starmer knowingly or unknowingly misled the Commons over Mandelson’s appointment as ambassador to the United States.

[Telegraaf](<https://www.telegraaf.nl/buitenland/geen-parlementair-onderzoek-naar-starmer-om-aanstelling-mandelson/150070346.html>) · published 2026-04-28T17:45:45+00:00 · observed on 2026-04-30
Capture `c-352e9d2657d41ccae8d0aa0e`

> Er komt geen parlementair onderzoek naar de Britse premier Keir Starmer. In het parlement wist de motie hiervoor geen meerderheid te behalen. Uit het onderzoek had duidelijk moeten worden of de sociaaldemocraat Starmer het Lagerhuis mogelijk bewust of onbewust heeft misleid in de affaire rond de benoeming van Peter Mandelson als ambassadeur in de Verenigde Staten.

Earlier source supporting this story/event link:

[BBC News](<https://www.bbc.com/news/articles/c3r3r2vzjp1o?at_medium=RSS&at_campaign=rss>) · published 2026-04-27T17:47:42+00:00 · observed on 2026-04-27
Capture `c-7f289d8bafdc192d06332212`

> No 10 brands the move "a desperate political stunt by the Conservative Party", which had asked for the vote.

## [Trial over arson attacks on property linked to Keir Starmer](stories/s-2dc7a385ff5c5ec9f8cc.md)

### Trial reporting describes charges and alleged Telegram recruitment

**New development** — NYT reports that a jury was told the men on trial over fires at two buildings and a car linked to Starmer last year were recruited through a Russian-language Telegram account. BBC identifies three men accused of targeting north London properties linked to Starmer.

[NYT](<https://www.nytimes.com/2026/04/29/world/europe/arson-keir-starmer-homes.html>) · published 2026-04-29T16:20:11+00:00 · observed on 2026-04-30
Capture `c-b84a8508775c9ffda70949d8`

> Two buildings and a car linked to Prime Minister Keir Starmer of Britain were set afire last year. The men on trial for it were recruited through a Russian-language Telegram account, a jury was told.

[BBC News](<https://www.bbc.com/news/articles/cx21y204zz4o?at_medium=RSS&at_campaign=rss>) · published 2026-04-29T15:01:41+00:00 · observed on 2026-04-30
Capture `c-cd4613d859a8e847d1d44523`

> The three men are accused of targeting north London properties linked to Prime Minister Sir Keir Starmer.

### Starmer’s sister-in-law describes fear after attack on her home

**New development** — The Guardian reports that Starmer’s sister-in-law told the court she feared what might have happened had she not woken during the attack on her home. The report connects that incident to the May 2025 series of attacks on Starmer-linked property and says the three accused men deny all charges.

[The Guardian](<https://www.theguardian.com/uk-news/2026/apr/30/starmers-sister-in-law-feared-what-might-have-happened-in-arson-attack-court-hears>) · published 2026-04-30T20:56:50+00:00 · observed on 2026-04-30
Capture `c-7f4f98851d708c8456ba7a10`

> The prime minister’s sister-in-law has said she feared what might have happened had she not woken up after her home was targeted in an arson attack, a court has heard.
> The incident is one of a series of arson attacks that took place in May last year on property linked to Keir Starmer, which three men with links to Ukraine are accused of targeting. They deny all the charges.
