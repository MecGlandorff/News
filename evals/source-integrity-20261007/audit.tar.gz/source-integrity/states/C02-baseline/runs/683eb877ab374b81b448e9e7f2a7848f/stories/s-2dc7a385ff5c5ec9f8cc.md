# Trial over arson attacks on property linked to Keir Starmer

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

First observed 2026-04-30 · latest observation 2026-04-30

## Observed on 2026-04-30

### Trial reporting describes charges and alleged Telegram recruitment

**New development** — NYT reports that a jury was told the men on trial over fires at two buildings and a car linked to Starmer last year were recruited through a Russian-language Telegram account. BBC identifies three men accused of targeting north London properties linked to Starmer.

[NYT](<https://www.nytimes.com/2026/04/29/world/europe/arson-keir-starmer-homes.html>) · published 2026-04-29T16:20:11+00:00 · observed on 2026-04-30
Capture `c-b84a8508775c9ffda70949d8`

> Two buildings and a car linked to Prime Minister Keir Starmer of Britain were set afire last year. The men on trial for it were recruited through a Russian-language Telegram account, a jury was told.

[BBC News](<https://www.bbc.com/news/articles/cx21y204zz4o?at_medium=RSS&at_campaign=rss>) · published 2026-04-29T15:01:41+00:00 · observed on 2026-04-30
Capture `c-cd4613d859a8e847d1d44523`

> The three men are accused of targeting north London properties linked to Prime Minister Sir Keir Starmer.

### Starmer’s sister-in-law describes fear after attack on her home

**New development** — The Guardian reports that Starmer’s sister-in-law told the court she feared what might have happened had she not woken during the attack on her home. The report connects that incident to the May 2025 series of attacks on Starmer-linked property and says the three accused men deny all charges.

[The Guardian](<https://www.theguardian.com/uk-news/2026/apr/30/starmers-sister-in-law-feared-what-might-have-happened-in-arson-attack-court-hears>) · published 2026-04-30T20:56:50+00:00 · observed on 2026-04-30
Capture `c-7f4f98851d708c8456ba7a10`

> The prime minister’s sister-in-law has said she feared what might have happened had she not woken up after her home was targeted in an arson attack, a court has heard.
> The incident is one of a series of arson attacks that took place in May last year on property linked to Keir Starmer, which three men with links to Ukraine are accused of targeting. They deny all the charges.
