# News — observed on 2026-04-27

Story links, summaries and change judgments are model interpretations. Quotes are checked against captured text, not verified as true. Observed on dates record capture, not when an event happened.

## [Musk’s damages lawsuit over OpenAI](stories/s-dc4153759149a0628ffc.md)

### Musk’s demand for more than $130bn in damages

**Change unclear** — BBC reports that Musk wants more than $130bn in damages. The excerpt does not establish when the demand was made or identify a procedural development.

[BBC News](<https://www.bbc.com/news/videos/ckger3y52k2o?at_medium=RSS&at_campaign=rss>) · published 2026-04-27T14:12:09+00:00 · observed on 2026-04-27
Capture `c-a48c62328b6de1725423dc9f`

> Musk, who co-founded the company that created ChatGPT with Altman, wants more than $130bn in damages.

## [OpenAI’s failure to alert police before the Tumbler Ridge shooting](stories/s-8b9ff537eb77b5761dc4.md)

### Altman posts apology letter over failure to notify law enforcement

**New development** — The Guardian reports that Altman apologized in a letter posted Friday for OpenAI’s failure to alert law enforcement about the online behavior of the person who killed eight people in Tumbler Ridge. OpenAI said it had identified an account but determined at the time that it did not meet the threshold for legal referral.

[The Guardian](<https://www.theguardian.com/us-news/2026/apr/25/altman-apologizes-after-openai-failed-to-alert-police-before-fatal-canada-shooting>) · published 2026-04-25T02:13:21+00:00 · observed on 2026-04-27
Capture `c-364676b1da09f6d9792b04b4`

> OpenAI said the company had identified an account using abuse-detection efforts, but determined at the time it didn’t meet threshold for legal referral

[The Guardian](<https://www.theguardian.com/us-news/2026/apr/25/altman-apologizes-after-openai-failed-to-alert-police-before-fatal-canada-shooting>) · published 2026-04-25T02:13:21+00:00 · observed on 2026-04-27
Capture `c-364676b1da09f6d9792b04b4`

> The head of OpenAI has written a letter apologizing that his company didn’t alert law enforcement about the online behavior of a person who shot and killed eight people in Tumbler Ridge, British Columbia.
> In the letter posted on Friday, Sam Altman expressed his deepest condolences to the entire community.
