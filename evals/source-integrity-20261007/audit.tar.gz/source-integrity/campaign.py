"""Explicit, bounded research campaign; never imported by the application/tests."""
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.news/source-integrity'
BASE = ROOT.parent / 'source-integrity-baseline-20261007'
LIVE = ROOT.parents[1] / 'from-scratch/.news/dogfood/memory'
FIELDS = ('id', 'source', 'url', 'title', 'text', 'published_at')


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_sources():
    from news.domain import digest
    pack = read(OUT / 'fresh-sources/sources.json')
    labels = read(OUT / 'fresh-sources/labels.json')
    assert sha(OUT / 'fresh-sources/sources.json') == labels['sources_file_sha256']
    versions = {v['id']: v for v in pack['source_versions']}
    with contextlib.closing(sqlite3.connect(Path(pack['archive']['path']).as_uri()+'?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        for v in versions.values():
            cols = ', '.join(pack['archive']['selected_columns'])
            actual = dict(db.execute(f'SELECT {cols} FROM article_occurrences WHERE occurrence_id=?', (v['raw_record']['occurrence_id'],)).fetchone())
            assert actual == v['raw_record']
            assert digest(actual) == v['provenance']['raw_record_sha256']
            assert digest(v['article']) == v['provenance']['normalized_article_sha256']
    spans = []
    def visit(value):
        if isinstance(value, dict):
            if {'source_id', 'field', 'quote', 'start', 'end'} <= value.keys():
                assert versions[value['source_id']]['article'][value['field']][value['start']:value['end']] == value['quote']
                spans.append(value)
            for item in value.values(): visit(item)
        elif isinstance(value, list):
            for item in value: visit(item)
    visit(labels)
    return pack, {'rows': len(versions), 'exact_spans': len(spans)}


def seed_prefix(target, before):
    from news import trajectory
    target.mkdir(parents=True, exist_ok=False)
    with contextlib.closing(sqlite3.connect((LIVE/'journal.sqlite3').as_uri()+'?mode=ro', uri=True)) as source:
        row = source.execute('SELECT rowid FROM runs WHERE id=?', (before,)).fetchone()[0]
        rows = source.execute('SELECT * FROM runs WHERE rowid < ? ORDER BY rowid', (row,)).fetchall()
    with contextlib.closing(trajectory.connect(target/'journal.sqlite3')) as db, db:
        db.executemany('INSERT INTO runs VALUES (?,?,?,?,?,?)', rows)
    return len(rows)


def prepare():
    from news import trajectory
    pack, checked = verify_sources()
    plan_path = OUT/'plan.json'
    assert not plan_path.exists(), 'Frozen plan already exists'
    snapshots = OUT/'inputs'
    items = {v['id']: v['article'] for v in pack['source_versions']}
    for case in pack['cases']:
        write(snapshots/(case['id']+'.json'), {'day':case['as_of_day'], 'articles':[items[k] for k in case['current_source_ids']]})
        for i, group in enumerate(case['prior_groups']):
            write(snapshots/f"{case['id']}-prior-{i}.json", {'day':group['day'], 'articles':[items[k] for k in group['source_ids']]})
    bad='10ce383566ff45ad8ccdb1b63af2fe6b'
    inherited='33718013455b4f38bd694246e5a79027'
    with contextlib.closing(sqlite3.connect((LIVE/'journal.sqlite3').as_uri()+'?mode=ro', uri=True)) as db:
        control=db.execute('SELECT id FROM runs ORDER BY rowid LIMIT 1').fetchone()[0]
    for label, rid in [('observed-bad',bad), ('inherited-bad',inherited), ('positive-control',control)]:
        payload=read(LIVE/'runs'/rid/'input.json')
        decision=read(LIVE/'runs'/rid/'decision.json')
        state=OUT/'states'/label
        seed_prefix(state, rid)
        with contextlib.closing(trajectory.connect(state/'journal.sqlite3')) as db:
            sources, stories=trajectory.project(db, as_of=payload['day'])
        write(snapshots/(label+'.json'),trajectory.coherence_payload(payload,decision,sources,stories))
        write(snapshots/(label+'-original-input.json'), payload)
    original=read(LIVE/'runs'/bad/'input.json')
    write(snapshots/'ship-cat.json',{'day':original['day'], 'articles':[{k:a[k] for k in FIELDS} for a in original['articles']]})
    later=read(LIVE/'runs'/inherited/'input.json')
    cat=next(a for a in later['articles'] if a['id']=='335bd8e8bb5da4c5bd57e22a')
    write(snapshots/'cat-followup.json',{'day':later['day'],'articles':[{k:cat[k] for k in FIELDS}]})
    for arm in ('baseline','candidate'):
        seed_prefix(OUT/'states'/('ship-cat-'+arm),bad)
    # Four previously observed headline gaps, composed source-only as of their latest day.
    ids=[('c7b0a44c6d3a426188a3055462e3d3f0','c-3ab2b96c53eaed4035577b1b'),('b86bb377b56144eeb98e5281b249dbb6','c-1e045ea2c2a61d1db05a5bd8'),('d5fd52a996344ca6b36388892dbc1e66','c-2fad5414949a1fc8a6c89461'),('484fa1669f6e42f8808050342b10fb77','c-378df0ec4dfdb2fd36bd79c0')]
    headlines=[]; days=[]
    for rid,cid in ids:
        payload=read(LIVE/'runs'/rid/'input.json'); days.append(payload['day'])
        a=next(a for a in payload['articles'] if a['capture_id']==cid)
        headlines.append({k:a[k] for k in FIELDS})
    write(snapshots/'headlines.json', {'day':max(days),'articles':headlines})
    frozen={str(p):sha(p) for p in sorted(snapshots.glob('*.json'))}
    frozen.update({str(p):sha(p) for p in (OUT/'fresh-sources').glob('*') if p.is_file()})
    original_files={str(p):sha(p) for p in LIVE.parent.rglob('*') if p.is_file() and p.name!='run.lock'}
    write(OUT/'original-files.json',original_files)
    write(plan_path, {'max_news_cli_calls':24,'planned_calls':24,'reserved_calls':0,
        'allocation':{'three_guard_controls':3,'ship_cat_two_arms':3,'cat_followup_two_arms':3,'shared_model_generated_prehistory':3,'three_fresh_cases_two_arms':9,'headlines_two_arms':3},
        'timeout_seconds_per_run_or_control':360,'model':'gpt-6-astra','reasoning':'medium',
        'prehistory':'C01: two chronological baseline prep runs; C02: one. Copy their unedited accepted rows identically to both arms. Preparation failures stop the dependent case; never hand-curate assignments.',
        'scoring':'Frozen source labels reviewed by root before outputs; same/different story pairs, separately event identity, omissions and attribution, rejected/failed cases, runtime and every call usage. No overall accuracy claim.',
        'known_regression':'Original bad decision must be rejected. Exact failing 8-article batch with all 6 prior accepted runs replayed in both arms, no edited decisions. Two ship sources must connect, cat matter must separate. Inherited contamination review must reject. A single original Oct6 cat article then follows each accepted replay, preserving its cat story identity and remaining separate from the ship. This is a composed continuation, not the full original Oct6 feed.',
        'headline_regression':'Composed four old-source gaps: Jupp appointment, Anthropic stopping tools, Day murder admission, Boots sold for £7bn. Measure supported headline-only developments; no claim this is the original full-batch replay.',
        'source_review':checked,'label_review':'Root read all 14 normalized sources, relationship/event rules and every reader expectation before new model outputs. Accepted source-only labels unchanged; exact spans/rows rechecked.',
        'frozen_files':frozen,'baseline_commit':'a5fef508c26e301a59c039e200e4f10b7adf9e1f'})
    print(json.dumps({'prepared':str(plan_path),'verified':checked}),flush=True)


def worker(code, label, mode, input_path, state):
    sys.path.insert(0,code)
    from news import trajectory
    for path, expected in read(OUT/'code-freeze.json').items(): assert sha(path)==expected,path
    plan=read(OUT/'plan.json')
    for path, expected in plan['frozen_files'].items(): assert sha(path)==expected,path
    normal=trajectory.run_task
    def counted(task,payload,directory,**kwargs):
        if task=='trajectory' and label in {c+'-'+a for c in ('C01','C02','C03') for a in ('baseline','candidate')}:
            case=next(c for c in read(OUT/'fresh-sources/sources.json')['cases'] if label.startswith(c['id']+'-'))
            assert {a['id'] for a in payload['articles']}==set(case['current_source_ids']), 'Missing current source cards'
            assert {a['id'] for a in payload['prior_sources']}==set(case['prior_source_ids']), 'Fixed-context case unavailable: missing prior source cards'
            write(OUT/'author-inputs'/(label+'.json'),payload)
            if label.endswith('-candidate'):
                assert payload==read(OUT/'author-inputs'/(case['id']+'-baseline.json')), 'Arms have different author inputs'
        if task=='trajectory' and label.startswith('ship-cat-'):
            assert payload==read(OUT/'inputs/observed-bad-original-input.json'), 'Original pre-failure input differs'
        calls=read(OUT/'calls.json') if (OUT/'calls.json').exists() else []
        assert len(calls)<plan['max_news_cli_calls'],'Campaign call ceiling reached'
        item={'ordinal':len(calls)+1,'label':label,'task':task,'artifact':str(directory),'status':'started_or_unknown'}
        calls.append(item);write(OUT/'calls.json',calls)
        start=time.monotonic()
        try:
            answer=normal(task,payload,directory,**kwargs);item['status']='returned';return answer
        except BaseException as exc:
            item.update(status='failed',error=str(exc));raise
        finally:
            item['wall_seconds']=round(time.monotonic()-start,6)
            metadata=directory/'metadata.json'
            item['metadata']=read(metadata) if metadata.exists() else None
            write(OUT/'calls.json',calls)
    trajectory.run_task=counted
    receipt={'label':label,'code':code,'mode':mode,'input':input_path,'state':state}
    started=time.monotonic()
    try:
        payload=read(input_path)
        if mode=='review':
            result=counted('coherence',payload,OUT/'controls'/label,timeout=360)
            write(OUT/'controls'/label/'review.json',result)
            try:
                trajectory.validate_coherence(payload['decision'],result);receipt['accepted']=True
            except ValueError as exc:
                receipt.update(accepted=False,rejection=str(exc))
        else:
            fixed_case=label in {c+'-'+a for c in ('C01','C02','C03') for a in ('baseline','candidate')}
            result,reused=trajectory.run(payload,Path(state),timeout=360,hits_per_article=10 if fixed_case else 3)
            receipt.update(accepted=True,run_id=result['run_id'],reused=reused)
        receipt['status']='completed'
    except BaseException as exc:
        receipt.update(status='failed',accepted=False,error=str(exc))
    finally:
        receipt['wall_seconds']=round(time.monotonic()-started,6)
        write(OUT/'receipts'/(label+'.json'),receipt)
        print(json.dumps(receipt),flush=True)


def launch(code,label,mode,input_path,state):
    assert not (OUT/'receipts'/(label+'.json')).exists(),'Never overwrite a completed attempt'
    subprocess.run([sys.executable,str(Path(__file__).resolve()),'worker',str(code),label,mode,str(input_path),str(state)],cwd=code,check=True)
    return read(OUT/'receipts'/(label+'.json'))


def run():
    plan=read(OUT/'plan.json')
    assert (OUT/'code-freeze.json').exists(),'Require independent preflight then code freeze'
    for path,expected in read(OUT/'code-freeze.json').items(): assert sha(path)==expected,path
    for label in ('observed-bad','inherited-bad','positive-control'):
        launch(ROOT,label,'review',OUT/'inputs'/(label+'.json'),OUT/'states'/label)
    for arm,code in [('baseline',BASE),('candidate',ROOT)]:
        initial=launch(code,'ship-cat-'+arm,'run',OUT/'inputs/ship-cat.json',OUT/'states'/('ship-cat-'+arm))
        if initial.get('accepted'):
            launch(code,'cat-followup-'+arm,'run',OUT/'inputs/cat-followup.json',OUT/'states'/('ship-cat-'+arm))
    pack=read(OUT/'fresh-sources/sources.json')
    for case in pack['cases']:
        name=case['id'];prep=OUT/'states'/(name+'-shared-prior');prep.mkdir(exist_ok=False)
        good=True
        for i,_ in enumerate(case['prior_groups']):
            receipt=launch(BASE,f'{name}-prior-{i}','run',OUT/'inputs'/f'{name}-prior-{i}.json',prep)
            if not receipt.get('accepted'):good=False;break
        if not good:continue
        for arm,code in [('baseline',BASE),('candidate',ROOT)]:
            state=OUT/'states'/(name+'-'+arm);state.mkdir(exist_ok=False)
            if (prep/'journal.sqlite3').exists():
                with contextlib.closing(sqlite3.connect((prep/'journal.sqlite3').as_uri()+'?mode=ro',uri=True)) as source, contextlib.closing(sqlite3.connect(state/'journal.sqlite3')) as dest:
                    source.backup(dest)
            launch(code,name+'-'+arm,'run',OUT/'inputs'/(name+'.json'),state)
    for arm,code in [('baseline',BASE),('candidate',ROOT)]:
        launch(code,'headlines-'+arm,'run',OUT/'inputs/headlines.json',OUT/'states'/('headlines-'+arm))
    assert len(read(OUT/'calls.json'))<=plan['max_news_cli_calls']
    changed=[p for p,h in read(OUT/'original-files.json').items() if sha(p)!=h]
    write(OUT/'original-verification.json',{'files':len(read(OUT/'original-files.json')),'changed':changed})
    assert not changed


if __name__=='__main__':
    if sys.argv[1]=='worker':worker(*sys.argv[2:])
    else:
        sys.path.insert(0,str(ROOT))
        {'prepare':prepare,'run':run}[sys.argv[1]]()
