"""A separately frozen, output-informed follow-up; never changes the first campaign."""
import contextlib
import importlib.util
from pathlib import Path
import sqlite3
import subprocess
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_campaign', HERE/'campaign.py')
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)
campaign.OUT = HERE/'followup'


def clone(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    with contextlib.closing(sqlite3.connect(source.as_uri()+'?mode=ro', uri=True)) as src, contextlib.closing(sqlite3.connect(target)) as dst:
        src.backup(dst)


def prepare():
    assert len(campaign.read(HERE/'calls.json')) == 19
    assert campaign.read(HERE/'original-verification.json')['changed'] == []
    out=campaign.OUT
    out.mkdir(exist_ok=False)
    (out/'fresh-sources').symlink_to(HERE/'fresh-sources',target_is_directory=True)
    plan={
        'max_news_cli_calls':5,'parent_calls':19,'total_campaign_ceiling':24,
        'classification':'Output-informed protocol amendment; not a fresh independent replication or a causal claim that the candidate fixes the original preparation error.',
        'reason':'The original C01 baseline preparation failed structural reference validation. It remains failed and C01 remains unavailable in the main campaign. No current C01 outcome was seen.',
        'order':['One candidate run of the identical second-prior snapshot from a copy of the unchanged first accepted baseline row (at most2calls).','Only after acceptance: one baseline current run, then one candidate current run, from identical copies of that complete accepted history (at most3calls).'],
        'stopping':'No retry, source/label edits, prompt edits or manual assignments. Any preparation/coverage failure leaves the dependent comparison unavailable. Unspent calls stay unspent.',
        'timeout_seconds_per_run':360,
        'context':'Same original frozen C01 cards and source-only labels; hits_per_article=10 and exact prior/current coverage and equal author payload assertions remain in the original worker.',
        'frozen_files':campaign.read(HERE/'plan.json')['frozen_files'] | {str(HERE/'calls.json'):campaign.sha(HERE/'calls.json')},
    }
    campaign.write(out/'plan.json',plan)
    source=HERE/'states/C01-shared-prior/journal.sqlite3'
    with contextlib.closing(sqlite3.connect(source.as_uri()+'?mode=ro',uri=True)) as db:
        rows=db.execute('SELECT id FROM runs ORDER BY rowid').fetchall()
    first=campaign.read(HERE/'receipts/C01-prior-0.json')['run_id']
    assert rows==[(first,)]
    clone(source,out/'states/C01-reviewed-prior/journal.sqlite3')
    frozen=campaign.read(HERE/'code-freeze.json')
    frozen.update({str(Path(__file__).resolve()):campaign.sha(__file__),str(out/'plan.json'):campaign.sha(out/'plan.json')})
    campaign.write(out/'code-freeze.json',frozen)
    print('Prepared separate follow-up: at most5calls; unchanged first accepted history row',first,flush=True)


def launch(code,label,input_path,state):
    assert not (campaign.OUT/'receipts'/(label+'.json')).exists()
    subprocess.run([sys.executable,str(Path(__file__).resolve()),'worker',str(code),label,'run',str(input_path),str(state)],cwd=code,check=True)
    return campaign.read(campaign.OUT/'receipts'/(label+'.json'))


def run():
    for path,h in campaign.read(campaign.OUT/'code-freeze.json').items(): assert campaign.sha(path)==h,path
    prep=campaign.OUT/'states/C01-reviewed-prior'
    receipt=launch(campaign.ROOT,'C01-reviewed-prior',HERE/'inputs/C01-prior-1.json',prep)
    if receipt.get('accepted'):
        for arm,code in [('baseline',campaign.BASE),('candidate',campaign.ROOT)]:
            state=campaign.OUT/'states'/('C01-'+arm)
            clone(prep/'journal.sqlite3',state/'journal.sqlite3')
            launch(code,'C01-'+arm,HERE/'inputs/C01.json',state)
    assert len(campaign.read(HERE/'calls.json'))+len(campaign.read(campaign.OUT/'calls.json'))<=24
    changed=[p for p,h in campaign.read(HERE/'original-files.json').items() if campaign.sha(p)!=h]
    campaign.write(campaign.OUT/'original-verification.json',{'files':844,'changed':changed})
    assert not changed


if __name__=='__main__':
    if sys.argv[1]=='worker':campaign.worker(*sys.argv[2:])
    else:{'prepare':prepare,'run':run}[sys.argv[1]]()
